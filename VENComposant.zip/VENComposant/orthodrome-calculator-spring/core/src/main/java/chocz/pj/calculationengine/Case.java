package chocz.pj.calculationengine;

public enum Case {
    SAME_POINT,
    MERIDIAN_SAIL,
    EQUATOR_SAIL,
    OPPOSITE_POINTS,
    GENERAL
}
