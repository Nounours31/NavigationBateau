package chocz.pj.util;

public class Mappings {

    public static final String CALCULATE = "calculate";
    public static final String HOME = "/";
    public static final String RESTART = "restart";
    public static final String REDIRECT_HOME = "redirect:/";

    private Mappings() {}
}
