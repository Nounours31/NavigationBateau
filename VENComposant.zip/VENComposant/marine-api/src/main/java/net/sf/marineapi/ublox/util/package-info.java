/**
 * Common library utils for u-blox vendor extensions
 */
package net.sf.marineapi.ublox.util;
