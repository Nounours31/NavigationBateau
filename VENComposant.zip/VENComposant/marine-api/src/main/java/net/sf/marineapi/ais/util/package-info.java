/**
 * AIS messaging related utils.
 */
package net.sf.marineapi.ais.util;