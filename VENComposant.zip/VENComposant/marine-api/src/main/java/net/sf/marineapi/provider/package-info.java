/**
 * Higher-level APIs that provide data updates for selected measurements.
 */
package net.sf.marineapi.provider;