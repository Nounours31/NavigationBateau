/**
 * AIS message events and listeners.
 */
package net.sf.marineapi.ais.event;