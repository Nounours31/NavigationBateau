/**
 * NMEA 0183 input/output.
 */
package net.sf.marineapi.nmea.io;