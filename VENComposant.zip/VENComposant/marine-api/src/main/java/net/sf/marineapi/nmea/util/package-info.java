/**
 * NMEA 0183 sentence utilities for handling the data extracted from sentences.
 */
package net.sf.marineapi.nmea.util;