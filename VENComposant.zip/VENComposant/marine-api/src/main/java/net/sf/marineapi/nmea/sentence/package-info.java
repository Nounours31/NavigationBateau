/**
 * NMEA 0183 sentence interfaces for supported sentences.
 */
package net.sf.marineapi.nmea.sentence;