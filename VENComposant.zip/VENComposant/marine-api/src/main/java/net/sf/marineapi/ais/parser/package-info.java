/**
 * AIS message parsers.
 */
package net.sf.marineapi.ais.parser;