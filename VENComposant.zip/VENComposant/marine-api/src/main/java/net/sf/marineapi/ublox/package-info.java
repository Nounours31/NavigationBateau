/**
 * Support for u-blox vendor extensions
 */
package net.sf.marineapi.ublox;