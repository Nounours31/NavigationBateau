/**
 * UBX message events and listeners.
 */
package net.sf.marineapi.ublox.event;
