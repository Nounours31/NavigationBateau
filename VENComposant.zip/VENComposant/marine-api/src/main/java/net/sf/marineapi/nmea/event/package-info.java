/**
 * NMEA 0183 events and listeners.
 */
package net.sf.marineapi.nmea.event;