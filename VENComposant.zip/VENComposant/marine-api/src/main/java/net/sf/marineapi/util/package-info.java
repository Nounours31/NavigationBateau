/**
 * Common library utils.
 */
package net.sf.marineapi.util;