/**
 * Provider events and listeners.
 */
package net.sf.marineapi.provider.event;