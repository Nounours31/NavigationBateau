/**
 * u-blox (P)UBX message interfaces.
 */
package net.sf.marineapi.ublox.message;
