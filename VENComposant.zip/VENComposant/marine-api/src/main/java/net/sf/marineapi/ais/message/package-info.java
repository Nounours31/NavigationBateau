/**
 * AIS message interfaces.
 */
package net.sf.marineapi.ais.message;