/**
 * Examples applications illustrating the usage of the Java Marine API
 */
package net.sf.marineapi.example;
