package net.sf.marineapi.test.util;

public interface FOOSentence {

	public abstract String getValueA();

	public abstract String getValueB();

	public abstract String getValueC();

}